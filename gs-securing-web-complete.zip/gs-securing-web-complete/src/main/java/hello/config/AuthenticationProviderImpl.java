/**
 * 
 */
package hello.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.stereotype.Component;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProviderClientBuilder;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthRequest;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthResult;
import com.amazonaws.services.cognitoidp.model.AuthFlowType;
import com.amazonaws.services.cognitoidp.model.NotAuthorizedException;
import com.amazonaws.services.cognitoidp.model.UserNotFoundException;

/**
 * @author Hirohito
 *
 */
@Component
public class AuthenticationProviderImpl implements AuthenticationProvider {

   private static String USER_POOL_ID = "ap-northeast-1_CbDB5rANY";
   private static String CLIENT_ID = "6jpmu3anhv27k5qr94mjfnop7v";

   /* (non-Javadoc)
    * @see org.springframework.security.authentication.AuthenticationProvider#authenticate(org.springframework.security.core.Authentication)
    */
   @Override
   public Authentication authenticate(Authentication authentication) throws AuthenticationException {
      String id = authentication.getName();
      String password = authentication.getCredentials().toString();
      System.out.println(id + " " + password);
      AdminInitiateAuthResult result = null;
      if ("".equals(id) || "".equals(password)) {
         // 例外はSpringSecurityにあったものを適当に使用
         throw new AuthenticationCredentialsNotFoundException("ログイン情報に不備があります。");
     }
     try {
        result = getResult(id, password);
     } catch (NotAuthorizedException ex) {
        System.out.println(ex.getErrorMessage());
        throw new AuthenticationCredentialsNotFoundException("ログイン情報が存在しません。");
     } catch (UserNotFoundException ex) {
        throw new AuthenticationCredentialsNotFoundException(ex.getErrorMessage());
     }
      
      return new UsernamePasswordAuthenticationToken(id, "", AuthorityUtils.createAuthorityList("USER"));
   }

   /* (non-Javadoc)
    * @see org.springframework.security.authentication.AuthenticationProvider#supports(java.lang.Class)
    */
   @Override
   public boolean supports(Class<?> token) {
      return UsernamePasswordAuthenticationToken.class.isAssignableFrom(token);
   }

   /**
    * Cognito接続用クライアントを生成する
    * 
    * @return　Cognito接続用クライアント
    */
   private AWSCognitoIdentityProvider createClient() {
      return AWSCognitoIdentityProviderClientBuilder.standard()
               .withCredentials(new ProfileCredentialsProvider())
               .withRegion(Regions.AP_NORTHEAST_1)
               .build();
   }
   
   
   /**
    * 認証の問い合わせを実行する
    * 
    * @param userId   ログインID
    * @param password パスワード
    * @return 認証結果情報
    */
   private AdminInitiateAuthResult getResult(String userId, String password) {
      AWSCognitoIdentityProvider client = createClient();
      AdminInitiateAuthRequest request = new AdminInitiateAuthRequest();
      Map<String, String> authParameters = new HashMap<String, String>();
      authParameters.put("USERNAME", userId);
      authParameters.put("PASSWORD", password);
      request.withAuthFlow(AuthFlowType.ADMIN_NO_SRP_AUTH)
               .withUserPoolId(USER_POOL_ID)
               .withClientId(CLIENT_ID)
               .withAuthParameters(authParameters);
      return client.adminInitiateAuth(request);
   }
}
