/**
 * 
 */
package sample.api.cognito;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProviderClientBuilder;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthRequest;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthResult;
import com.amazonaws.services.cognitoidp.model.AuthFlowType;
import com.amazonaws.services.cognitoidp.model.NotAuthorizedException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Hirohito
 *
 */
public class CognitoApiTest {

	private static String USER_POOL_ID = "ap-northeast-1_CbDB5rANY";
	private static String CLIENT_ID = "6jpmu3anhv27k5qr94mjfnop7v";
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		CognitoApiTest test = new CognitoApiTest();
		AdminInitiateAuthResult result = null;
		try {
			result = test.getResult("user01", "hi39ro52");
		} catch (NotAuthorizedException e) {
			System.out.println(e.getErrorMessage());
			return;
		}
		System.out.println(result.getAuthenticationResult().toString());
		String accessToken = result.getAuthenticationResult().getAccessToken();
		test.verifyAccessToken(accessToken);
	}
	
	/**
	 * Cognito接続用クライアントを生成する
	 * 
	 * @return　Cognito接続用クライアント
	 */
	public AWSCognitoIdentityProvider createClient() {
		return AWSCognitoIdentityProviderClientBuilder.standard()
					.withCredentials(new ProfileCredentialsProvider())
					.withRegion(Regions.AP_NORTHEAST_1)
					.build();
	}
	
	
	/**
	 * 認証の問い合わせを実行する
	 * 
	 * @param userId   ログインID
	 * @param password パスワード
	 * @return 認証結果情報
	 */
	public AdminInitiateAuthResult getResult(String userId, String password) {
		AWSCognitoIdentityProvider client = createClient();
		AdminInitiateAuthRequest request = new AdminInitiateAuthRequest();
		Map<String, String> authParameters = new HashMap<String, String>();
		authParameters.put("USERNAME", userId);
		authParameters.put("PASSWORD", password);
		request.withAuthFlow(AuthFlowType.ADMIN_NO_SRP_AUTH)
					.withUserPoolId(USER_POOL_ID)
					.withClientId(CLIENT_ID)
					.withAuthParameters(authParameters);
		return client.adminInitiateAuth(request);
	}

	
	/**
	 * アクセストークンを検証する
	 * @param accessToken
	 * @return
	 * @throws IOException 
	 */
	public boolean verifyAccessToken(String accessToken) throws IOException {
		boolean result = false;
		String url = "https://cognito-idp.ap-northeast-1"  
							+ ".amazonaws.com/" + USER_POOL_ID 
							+ "/.well-known/jwks.json";
		CloseableHttpClient client = HttpClients.createDefault();
		HttpGet httpGet = new HttpGet(url);
		CloseableHttpResponse response = client.execute(httpGet);
		InputStream stream = response.getEntity().getContent();
		BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
		String body = reader.lines().collect(Collectors.joining(System.getProperty("line.separator")));
		System.out.println(body);
		client.close();

		String[] tokens = accessToken.split("\\.");
		System.out.println("token = " +  tokens[1]);
		String head = new String(Base64.getDecoder().decode(tokens[0].getBytes()));
		String json = new String(Base64.getDecoder().decode(tokens[1].getBytes()));
		System.out.println(head);
		System.out.println(json);
		@SuppressWarnings("rawtypes")
		Map readValue = new ObjectMapper().readValue(json, LinkedHashMap.class);
		System.out.println(readValue.get("iss"));
		System.out.println(readValue.get("token_use"));
		Map<String, List<Map<String, String>>> bodyList = new ObjectMapper().readValue(body, new TypeReference<Map<String, List<Map<String, String>>>>() {});
		System.out.println(bodyList.get("keys").get(0).get("e"));
		
		if(!url.equals(readValue.get("iss"))) {
			return false;
		} else if (!"access".equals(readValue.get("token_use"))) {
			return false;
		}
		
		return result;
	}
}
